package com.example.finalprojectpuzzle.RoomDataBase;

import android.app.Application;

import androidx.lifecycle.LiveData;


import java.util.List;

public class MyRepository {
    private PersonDao personDao;
    private LevelDao levelDao;

    private LiveData<List<Person>> allPerson;
    private LiveData<List<Level>> allLevel;
    MyRepository(Application application){
      MyRoomDataBase db=  MyRoomDataBase.getDatabase(application);
        personDao =db.personDao();
        levelDao=db.levelDao();
        allPerson=personDao.getAllPerson();
        allLevel=levelDao.getAllLevel();


    }

    void insertPerson(Person person){
        MyRoomDataBase.databaseWriteExecutor.execute(new Runnable() {
            @Override
            public void run() {
                personDao.insertPerson(person);
            }
        });
    }

    void DeletePerson(Person person){
        MyRoomDataBase.databaseWriteExecutor.execute(new Runnable() {
            @Override
            public void run() {
                personDao.DeletePerson(person);
            }
        });
    }

    void UpdatePerson(Person person){
        MyRoomDataBase.databaseWriteExecutor.execute(new Runnable() {
            @Override
            public void run() {
                personDao.UpdatePerson(person);
            }
        });
    }

    LiveData<List<Person>> getAllPerson(){
        return personDao.getAllPerson();
    }
    void insertLevel(Level level){
        MyRoomDataBase.databaseWriteExecutor.execute(new Runnable() {
            @Override
            public void run() {
                levelDao.insertLevel(level);
            }
        });
    }

    void DeleteLevel(Level level){
        MyRoomDataBase.databaseWriteExecutor.execute(new Runnable() {
            @Override
            public void run() {levelDao.DeleteLevel(level);}
        });
    }

    void UpdateLevel(Level level){
        MyRoomDataBase.databaseWriteExecutor.execute(new Runnable() {
            @Override
            public void run() {
                levelDao.UpdateLevel(level);
            }
        });
    }

    LiveData<List<Level>> getAllLevel(){
        return levelDao.getAllLevel();
    }
}


