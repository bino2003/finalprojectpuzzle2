package com.example.finalprojectpuzzle.RoomDataBase;

import androidx.annotation.NonNull;
import androidx.room.Entity;
import androidx.room.PrimaryKey;


    @Entity
    public class Person {
        @PrimaryKey(autoGenerate = true)
        private   int id;
        @NonNull
        private String FullName;
        @NonNull


        private String Email;
        @NonNull

        private    String UserName;
        @NonNull

        private    String password;
        @NonNull

        private String Nationality;
        @NonNull

        private String DateOfBirth;
        @NonNull

        private String Gender;

        @Override
        public String toString() {
            return "Person{" +
                    "id=" + id +
                    ", FullName='" + FullName + '\'' +
                    ", Email='" + Email + '\'' +
                    ", UserName='" + UserName + '\'' +
                    ", password='" + password + '\'' +
                    ", Nationality='" + Nationality + '\'' +
                    ", DateOfBirth='" + DateOfBirth + '\'' +
                    ", Gender='" + Gender + '\'' +
                    '}';
        }

        public int getId() {
            return id;
        }

        public void setId(int id) {
            this.id = id;
        }

        public String getFullName() {
            return FullName;
        }

        public void setFullName(String fullName) {
            FullName = fullName;
        }

        public String getEmail() {
            return Email;
        }

        public void setEmail(String email) {
            Email = email;
        }

        public String getUserName() {
            return UserName;
        }

        public void setUserName(String userName) {
            UserName = userName;
        }

        public String getPassword() {
            return password;
        }

        public void setPassword(String password) {
            this.password = password;
        }

        public String getNationality() {
            return Nationality;
        }

        public void setNationality(String nationality) {
            Nationality = nationality;
        }

        public String getDateOfBirth() {
            return DateOfBirth;
        }

        public void setDateOfBirth(String dateOfBirth) {
            DateOfBirth = dateOfBirth;
        }

        public String getGender() {
            return Gender;
        }

        public void setGender(String gender) {
            Gender = gender;
        }

        public Person() {

        }

        public Person(int id, String fullName, String email, String userName, String password, String nationality, String dateOfBirth, String gender) {
            this.id = id;
            FullName = fullName;
            Email = email;
            UserName = userName;
            this.password = password;
            Nationality = nationality;
            DateOfBirth = dateOfBirth;
            Gender = gender;
        }

        public Person(String fullName, String email, String userName, String password, String nationality, String dateOfBirth, String gender) {
            FullName = fullName;
            Email = email;
            UserName = userName;
            this.password = password;
            Nationality = nationality;
            DateOfBirth = dateOfBirth;
            Gender = gender;
        }
    }


