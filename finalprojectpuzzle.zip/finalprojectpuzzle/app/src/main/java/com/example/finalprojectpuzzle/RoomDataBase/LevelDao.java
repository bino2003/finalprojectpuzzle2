package com.example.finalprojectpuzzle.RoomDataBase;

import androidx.lifecycle.LiveData;
import androidx.room.Delete;
import androidx.room.Insert;
import androidx.room.Query;
import androidx.room.Update;

import com.example.finalprojectpuzzle.RoomDataBase.Level;

import java.util.List;

    public interface LevelDao {
        @Insert
        void insertLevel(Level level);
        @Delete
        void DeleteLevel(Level level);
        @Update
        void UpdateLevel(Level level);
        @Query("select * from Level")
        LiveData<List<Level>> getAllLevel();

    }

