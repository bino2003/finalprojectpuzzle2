package com.example.finalprojectpuzzle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.room.RoomDatabase;

import android.os.Bundle;
import android.util.Log;

import com.example.finalprojectpuzzle.RoomDataBase.MyRepository;
import com.example.finalprojectpuzzle.RoomDataBase.MyViewModel;
import com.example.finalprojectpuzzle.databinding.ActivityPlayingStartBinding;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

public class PlayingStart extends AppCompatActivity {
ActivityPlayingStartBinding binding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding=ActivityPlayingStartBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());
        MyViewModel myViewModel= new ViewModelProvider(this).get(MyViewModel.class);
        
String json=AppUtility.readFromAssets(PlayingStart.this,"Puzzle.json");
        try {
            JSONArray PlayingJsonArray=new JSONArray(json);
            ArrayList playingArrayList=new ArrayList();
            for (int i = 0; i < PlayingJsonArray.length(); i++) {
                JSONObject PlayingJsonObject=new JSONObject(PlayingJsonArray.get(i).toString());
                PlayingJsonObject.getInt("level_no");
                PlayingJsonObject.getInt("unlock_points");

                    JSONArray questionsJsonArray=PlayingJsonObject.getJSONArray("questions");
                    ArrayList questionsArrayList=new ArrayList();
                Log.d(" questions", String.valueOf(questionsJsonArray.length()));
                    for (int x = 0; x < questionsJsonArray.length(); x++) {
                        JSONObject questionsJsonObject=new JSONObject(questionsJsonArray.get(i).toString());
                        questionsJsonObject.getInt("id");
                        questionsJsonObject.getString("title");
                        questionsJsonObject.getString("answer_1");
                        questionsJsonObject.getString("answer_2");
                        questionsJsonObject.getString("answer_3");
                        questionsJsonObject.getString("answer_4");
                        questionsJsonObject.getString("true_answer");
                        questionsJsonObject.getInt("points");
                        questionsJsonObject.getInt("duration");
               JSONObject patternJsonObject=         questionsJsonObject.getJSONObject("pattern");
               patternJsonObject.getInt("pattern_id");
               patternJsonObject.getString("pattern_name");
               questionsJsonObject.getString("hint");
                        JSONObject questions2JsonObject=new JSONObject(questionsJsonArray.get(i).toString());
                        questions2JsonObject.getInt("id");
                        questions2JsonObject.getString("title");
                        questions2JsonObject.getString("answer_1");
                        questions2JsonObject.getString("answer_2");
                        questions2JsonObject.getString("answer_3");
                        questions2JsonObject.getString("answer_4");
                        questions2JsonObject.getString("true_answer");
                        questions2JsonObject.getInt("points");
                        questions2JsonObject.getInt("duration");
                        JSONObject pattern2JsonObject=         questionsJsonObject.getJSONObject("pattern");
                        pattern2JsonObject.getInt("pattern_id");
                        pattern2JsonObject.getString("pattern_name");
                        pattern2JsonObject.getString("hint");
                        JSONObject questions3JsonObject=new JSONObject(questionsJsonArray.get(i).toString());
                        questions3JsonObject.getInt("id");
                        questions3JsonObject.getString("title");
                        questions3JsonObject.getString("answer_1");
                        questions3JsonObject.getString("answer_2");
                        questions3JsonObject.getString("answer_3");
                        questions3JsonObject.getString("answer_4");
                        questions3JsonObject.getString("true_answer");
                        questions3JsonObject.getInt("points");
                        questions3JsonObject.getInt("duration");
                        JSONObject pattern3JsonObject=         questionsJsonObject.getJSONObject("pattern");
                        pattern3JsonObject.getInt("pattern_id");
                        pattern3JsonObject.getString("pattern_name");
                        pattern3JsonObject.getString("hint");
                        JSONObject questions4JsonObject=new JSONObject(questionsJsonArray.get(i).toString());
                        questions4JsonObject.getInt("id");
                        questions4JsonObject.getString("title");
                        questions4JsonObject.getString("answer_1");
                        questions4JsonObject.getString("answer_2");
                        questions4JsonObject.getString("answer_3");
                        questions4JsonObject.getString("answer_4");
                        questions4JsonObject.getString("true_answer");
                        questions4JsonObject.getInt("points");
                        questions4JsonObject.getInt("duration");
                        JSONObject pattern4JsonObject=         questionsJsonObject.getJSONObject("pattern");
                        pattern4JsonObject.getInt("pattern_id");
                        pattern4JsonObject.getString("pattern_name");
                        pattern4JsonObject.getString("hint");








                    }
                JSONObject Playing2JsonObject=new JSONObject(PlayingJsonArray.get(i).toString());
                Playing2JsonObject.getInt("level_no");
                Playing2JsonObject.getInt("unlock_points");

                JSONArray questions2JsonArray=PlayingJsonObject.getJSONArray("questions");
                ArrayList questions2ArrayList=new ArrayList();
                for (int x = 0; x < questions2JsonArray.length(); x++) {
                    JSONObject questionsJsonObject=new JSONObject(questions2JsonArray.get(i).toString());
                    questionsJsonObject.getInt("id");
                    questionsJsonObject.getString("title");
                    questionsJsonObject.getString("answer_1");
                    questionsJsonObject.getString("answer_2");
                    questionsJsonObject.getString("answer_3");
                    questionsJsonObject.getString("answer_4");
                    questionsJsonObject.getString("true_answer");
                    questionsJsonObject.getInt("points");
                    questionsJsonObject.getInt("duration");
                    JSONObject patternJsonObject=         questionsJsonObject.getJSONObject("pattern");
                    patternJsonObject.getInt("pattern_id");
                    patternJsonObject.getString("pattern_name");
                    questionsJsonObject.getString("hint");
                    JSONObject questions2JsonObject=new JSONObject(questionsJsonArray.get(i).toString());
                    questions2JsonObject.getInt("id");
                    questions2JsonObject.getString("title");
                    questions2JsonObject.getString("answer_1");
                    questions2JsonObject.getString("answer_2");
                    questions2JsonObject.getString("answer_3");
                    questions2JsonObject.getString("answer_4");
                    questions2JsonObject.getString("true_answer");
                    questions2JsonObject.getInt("points");
                    questions2JsonObject.getInt("duration");
                    JSONObject pattern2JsonObject=         questionsJsonObject.getJSONObject("pattern");
                    pattern2JsonObject.getInt("pattern_id");
                    pattern2JsonObject.getString("pattern_name");
                    pattern2JsonObject.getString("hint");
                    JSONObject questions3JsonObject=new JSONObject(questionsJsonArray.get(i).toString());
                    questions3JsonObject.getInt("id");
                    questions3JsonObject.getString("title");
                    questions3JsonObject.getString("answer_1");
                    questions3JsonObject.getString("answer_2");
                    questions3JsonObject.getString("answer_3");
                    questions3JsonObject.getString("answer_4");
                    questions3JsonObject.getString("true_answer");
                    questions3JsonObject.getInt("points");
                    questions3JsonObject.getInt("duration");
                    JSONObject pattern3JsonObject=         questionsJsonObject.getJSONObject("pattern");
                    pattern3JsonObject.getInt("pattern_id");
                    pattern3JsonObject.getString("pattern_name");
                    pattern3JsonObject.getString("hint");
                    JSONObject questions4JsonObject=new JSONObject(questionsJsonArray.get(i).toString());
                    questions4JsonObject.getInt("id");
                    questions4JsonObject.getString("title");
                    questions4JsonObject.getString("answer_1");
                    questions4JsonObject.getString("answer_2");
                    questions4JsonObject.getString("answer_3");
                    questions4JsonObject.getString("answer_4");
                    questions4JsonObject.getString("true_answer");
                    questions4JsonObject.getInt("points");
                    questions4JsonObject.getInt("duration");
                    JSONObject pattern4JsonObject=         questionsJsonObject.getJSONObject("pattern");
                    pattern4JsonObject.getInt("pattern_id");
                    pattern4JsonObject.getString("pattern_name");
                    pattern4JsonObject.getString("hint");








                }





            }
        } catch (JSONException e) {
            e.printStackTrace();
        }


    }

}