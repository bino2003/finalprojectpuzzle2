package com.example.finalprojectpuzzle.RoomDataBase;

import android.app.Application;

import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.LiveData;

import com.example.finalprojectpuzzle.RoomDataBase.MyRepository;

import java.util.List;

public class MyViewModel extends AndroidViewModel {

    private MyRepository myRepository;



    public MyViewModel (Application application) {
        super(application);
        myRepository = new MyRepository(application);

    }
    void insertPerson(Person person){
        myRepository.insertPerson(person);
    }

    void DeletePerson(Person person){
      myRepository.DeletePerson(person);
    }

    void UpdatePerson(Person person){
       myRepository.UpdatePerson(person);
    }

    LiveData<List<Person>> getAllPerson(){
        return myRepository.getAllPerson();
    }
    void insertLevel(Level level){
        myRepository.insertLevel(level);
    }

    void DeleteLevel(Level level){
        myRepository.DeleteLevel(level);
    }

    void UpdateLevel(Level level){
        myRepository.UpdateLevel(level);
    }

    LiveData<List<Level>> getAllLevel(){
        return myRepository.getAllLevel();
    }


}
