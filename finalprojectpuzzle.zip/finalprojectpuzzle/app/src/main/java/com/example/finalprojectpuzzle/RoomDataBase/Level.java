package com.example.finalprojectpuzzle.RoomDataBase;

import androidx.room.Entity;


    @Entity
    public class Level {
        String Level;
        String Num_q;
        boolean isopen;
        String Num_allPoint;
        String Num_playerPoint;

        public String getLevel() {
            return Level;
        }

        public void setLevel(String level) {
            Level = level;
        }

        public String getNum_q() {
            return Num_q;
        }

        public void setNum_q(String num_q) {
            Num_q = num_q;
        }

        public boolean isIsopen() {
            return isopen;
        }

        public void setIsopen(boolean isopen) {
            this.isopen = isopen;
        }

        public String getNum_allPoint() {
            return Num_allPoint;
        }

        public void setNum_allPoint(String num_allPoint) {
            Num_allPoint = num_allPoint;
        }

        public String getNum_playerPoint() {
            return Num_playerPoint;
        }

        public void setNum_playerPoint(String num_playerPoint) {
            Num_playerPoint = num_playerPoint;
        }

        public Level(String level, String num_q, boolean isopen, String num_allPoint, String num_playerPoint) {
            Level = level;
            Num_q = num_q;
            this.isopen = isopen;
            Num_allPoint = num_allPoint;
            Num_playerPoint = num_playerPoint;
        }
    }




