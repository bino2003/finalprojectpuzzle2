package com.example.finalprojectpuzzle;

public interface OnClickItem {
    void onclick(int levelnum);
}
